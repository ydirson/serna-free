class T {
	static { int i; }

	void foo() {
		class U { int i; }
		Class c = int[].class;
		t.new T();
		((T)t).method();
		this( (int) (r * 255), (int) (g * 255));
		return "[i=" + (value) + "]";
	}
}
