package tinybasic;

//import antlr.ParserException;

public class DTExecException extends RuntimeException{


	public DTExecException(String s){
		super(s);
	}

}
